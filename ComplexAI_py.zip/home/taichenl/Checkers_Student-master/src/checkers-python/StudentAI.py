import copy
from math import sqrt, log

from random import randint
from BoardClasses import Move
from BoardClasses import Board
#The following part should be completed by students.
#Students can modify anything except the class name and exisiting functions and varibles.


def flat_board(board):
    board = board.board
    state = ''
    for i, row in enumerate(board):
        state += ''.join(i.color for i in row)
        if i < len(board) - 1:
            state += '\n'
    return state


class StudentAI():

    DEFAULT_N = 0
    DEFAULT_Q = 0
    CONST_C = 1
    MAX_TRIAL = 15

    class UctTreeNode:

        opponent = {1:2, 2:1}

        @staticmethod
        def __flatten_dict(dict_2d):
            return [item for row in dict_2d.values() for item in row.values()]

        @staticmethod
        def __flatten_list(list_2d):
            return [item for row in list_2d for item in row]

        @property
        def has_unexplored(self):
            return len(self.unexplored_actions) > 0

        @property
        def is_gameover(self):
            return self.board.is_win(self.turn) != 0


        def __init__(self, board, turn, unexplored_actions, botturn, parent=None, n = 0, t = 0):
            self.board = board
            self.turn = turn
            self.unexplored_actions = self.__flatten_list(unexplored_actions)
            self.children = []
            self.botturn = botturn
            self.parent = parent
            self.n = StudentAI.DEFAULT_N
            self.q = StudentAI.DEFAULT_Q
            self.num = n;
            self.time = t;

        def state_hash(self):
            board = self.board.board
            state = ''
            for i, row in enumerate(board):
                state += ''.join(i.color for i in row)
                if i < len(board)-1:
                    state += '\n'
            # flatmap = [chk.color for row in board for chk in row]
            # state = ''.join(flatmap)
            return state

        def expand_one_child(self):
            action = self.unexplored_actions.pop()
            self.board.make_move(action, self.turn)
            child_board = copy.deepcopy(self.board)
            child_turn = self.opponent[self.turn]
            child_actions = child_board.get_all_possible_moves(child_turn)
            child_node = StudentAI.UctTreeNode(child_board, child_turn, child_actions, self.botturn, parent=self)
            self.children.append(child_node)
            self.board.undo()
            # print('[exploring] expand one')

            # selfmap = self._state_hash()
            # childmap = child_node._state_hash()
            # print('-'*20)
            # print('from:')
            # print(selfmap)
            # print('to:')
            # print(childmap)
            # print('-'*20)

            return child_node

        def best_one_child(self, cp):
            max_child, max_score = None, float('-inf')
            for child in self.children:
                exploit = child.q / child.n
                explore = cp * sqrt(2*log(self.n)/child.n)
                score = exploit + explore
                if score > max_score:
                    max_child = child
                    max_score = score
            # print('[exploring] best one')
            return max_child


        def select_child(self):
            # the Tree Policy
            node = self
            while not node.is_gameover:
                if node.has_unexplored:
                    return node.expand_one_child()
                else:
                    next_node = node.best_one_child(StudentAI.CONST_C)
                    if next_node is None:
                        break
                    node = next_node
            return node

        @staticmethod
        def _random_explore(board, turn):
            new_board = copy.deepcopy(board)
            moves = new_board.get_all_possible_moves(turn)
            index = randint(0, len(moves) - 1)
            inner_index = randint(0, len(moves[index]) - 1)
            move = moves[index][inner_index]
            new_board.make_move(move, turn)
            return new_board


        def _state_reward(self, board, turn):
            win = board.is_win(turn)
            #assert win != 0
            if win == -1 or win == 0:   # draw
                return 0
            elif win == self.botturn:  # this AI wins
                return 1
            else:                   # this AI loses
                return -1
        
        #def myBoardeval(board):
            
        def simulate_state(self):
            # the Default Policy
            board = self.board
            turn = self.opponent[self.turn]
            count = 0;
            while board.is_win(turn) == 0: # game is not over
                turn = self.opponent[turn]
                if (count >90):
                    break;
                count = count +1;
                #print('current board:\n', flat_board(board), '\nturn: ', turn, sep='')
                # print('-'*100)
                board = self._random_explore(board, turn)
            return self._state_reward(board, turn)

        def propagate_reward(self, delta):
            # the backup
            node = self
            while node is not None:
                node.n += 1
                node.q += delta
                node = node.parent


    def __init__(self,col,row,p):
        self.col = col
        self.row = row
        self.p = p
        self.board = Board(col,row,p)
        self.board.initialize_game()
        self.color = ''
        self.opponent = {1:2,2:1}
        self.color = 2



    def run_current_simulation(self):
        moves = self.board.get_all_possible_moves(self.color)
        v0 = StudentAI.UctTreeNode(self.board, self.color, moves, self.color)
        for _ in range(StudentAI.MAX_TRIAL):
            vt = v0.select_child()

            # print('select vt')
            # print(vt.state_hash())

            delta = vt.simulate_state()
            vt.propagate_reward(delta)
        return v0

    def get_move(self, move):
        if len(move) != 0:  # run how opponent acts
            self.board.make_move(move, self.opponent[self.color])
        else:
            self.color = 1

        mctree = self.run_current_simulation()
        best_child = mctree.best_one_child(0)
        move = best_child.board.saved_move[-1][0]

        self.board.make_move(move, self.color)
        return move
